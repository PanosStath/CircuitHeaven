import java.io.Serializable;

public class Description implements Serializable {
    private int productId;
    private String productName;
    private String description;
    private double startingBid;
    private double currentBid; // field to store the current highest bid

    public Description(int productId, String productName, String description, double startingBid) {
        this.productId = productId;
        this.productName = productName;
        this.description = description;
        this.startingBid = startingBid;
        this.currentBid = startingBid; 
    }

    public int getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public String getDescription() {
        return description;
    }

    public double getStartingBid() {
        return startingBid;
    }

    public double getCurrentBid() {
        return currentBid;
    }

    public void setCurrentBid(double bid) {
        this.currentBid = bid;
    }
}