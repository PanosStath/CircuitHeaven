import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Products {
    private List<Description> productList;
    private static final String FILE_PATH = "products.txt";

    public Products() {
        productList = new ArrayList<>();
        loadProducts();
    }

    private void loadProducts() {
        try {
            List<String> lines = FileHelper.readFileLines(FILE_PATH);
            for (String line : lines) {
                Description product = parseDescription(line);
                productList.add(product);
            }
        } catch (IOException e) {
            System.out.println("Failed to load products: " + e.getMessage());
        }
    }

    private Description parseDescription(String line) {
        String[] fields = line.split(",");
        if(fields.length < 1){
            throw new IllegalArgumentException("Invalid input line: " + line);
        }
        try{
        int id = Integer.parseInt(fields[0].trim());
        String name = fields[1].trim();
        String description = fields[2].trim();
        double startingBid = Double.parseDouble(fields[3].trim());
        return new Description(id, name, description, startingBid);
    } catch (NumberFormatException e) {
        throw new IllegalArgumentException("Invalid format in input line: " +line, e);
    }
}

    public List<Description> getProductList() {
        return productList;
    }

    public void addProduct(Description product) {
        productList.add(product);
        saveProducts();
    }

    private void saveProducts() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Description product : productList) {
                String line = formatProduct(product);
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Failed to save products: " + e.getMessage());
        }
    }

    private String formatProduct(Description product) {
        return product.getProductId() + "," + product.getProductName() + "," + product.getDescription() + "," + product.getStartingBid();
    }
}