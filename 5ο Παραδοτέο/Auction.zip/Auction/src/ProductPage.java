import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;

public class ProductPage {
    private List<Description> productList;
    private Map<Integer, Double> bidMap;

    public ProductPage(List<Description> productList) {
        this.productList = productList;
        this.bidMap = new HashMap<>();
    }

    public void displayPrompt() {
        if (productList == null || productList.isEmpty()) {
            System.out.println("No products currently on auction.");
            return;
        } else {
            System.out.println("These are the products currently on auction:");

            for (int i = 0; i < productList.size(); i++) {
                Description product = productList.get(i);
                System.out.println((i + 1) + ". " + product.getProductName());
                System.out.println("   Description: " + product.getDescription());
                System.out.println("   Starting Bid: $" + product.getStartingBid());
            }
        }

        try (Scanner scanner = new Scanner(System.in).useLocale(Locale.US)) {
            while (true) {
                System.out.println("Please choose a product:");

                for (int i = 0; i < productList.size(); i++) {
                    Description product = productList.get(i);
                    System.out.println((i + 1) + ". " + product.getProductName());
                }

                if (scanner.hasNextInt()) {
                    int choice = scanner.nextInt();
                    scanner.nextLine(); // Clear intager from scanner

                    if (choice >= 1 && choice <= productList.size()) {
                        Description chosenProduct = productList.get(choice - 1);
                        System.out.println("You have chosen '" + chosenProduct.getProductName() + "'.");
                        double bid;

                        do {
                            System.out.println("Place your bid for the product:");
                            if (scanner.hasNextDouble()) {
                                bid = scanner.nextDouble();
                                scanner.nextLine(); // Consume the newline character after reading the double

                                if (bid <= chosenProduct.getStartingBid()) {
                                    System.out.println("Sorry, your bid should be higher than the starting bid.");
                                } else {
                                    bidMap.put(chosenProduct.getProductId(), bid); 
                                    break; 
                                }
                            } else {
                                System.out.println("Invalid input. Please enter a valid bid.");
                                scanner.nextLine(); 
                                bid = -1; // Set bid to an invalid value to continue loop
                            }
                        } while (true);

                        System.out.println("Congratulations! Your bid is higher than the starting bid.");
                        System.out.println("You have won the auction, the product will arrive...\n");
                        String estimatedArrival = "2023-05-30"; // Placeholder for estimatedArrival
                        ArrivingProduct arrivingProduct = new ArrivingProduct(estimatedArrival);
                        arrivingProduct.displayPrompt();
                        
                        return;
                    } else {
                        System.out.println("Invalid choice. Please try again.");
                    }
                } else {
                    System.out.println("Invalid input. Please enter a valid option.");
                    scanner.nextLine(); 
                }
            }
        }
    }
}