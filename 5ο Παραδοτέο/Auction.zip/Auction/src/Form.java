import java.util.Scanner;

public class Form {
    public Description fillForm() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Fill out the form of your product:");

        System.out.print("Product Name: ");
        String productName = scanner.nextLine();

        System.out.print("Description: ");
        String description = scanner.nextLine();

        System.out.print("Starting Bid: ");
        double startingBid = scanner.nextDouble();

        Description product = new Description(0, productName, description, startingBid);

        return product;
    }
}