public class ArrivingProduct {
    private String estimatedArrival;

    public ArrivingProduct(String estimatedArrival) {
        this.estimatedArrival = estimatedArrival;
    }

    public void displayPrompt() {
        System.out.println("Estimated arrival date: " + estimatedArrival);
    }
}

