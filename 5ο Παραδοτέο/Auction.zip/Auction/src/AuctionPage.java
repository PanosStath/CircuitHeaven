import java.util.Scanner;
import java.util.List;

public class AuctionPage {
    public static void displayPrompt(List<Description> productList) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Auction Page!");
        int choice;

        while (true) {
            System.out.println("Please choose an option:");
            System.out.println("1. Customer");
            System.out.println("2. Seller");

            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        System.out.println("You have chosen 'Customer'.");
                        // customer-related
                        new ProductPage(productList).displayPrompt();
                        return;
                    case 2:
                        System.out.println("You have chosen 'Seller'.");
                        // seller-related 
                        Form form = new Form();
                        Description productDescription = form.fillForm();
                        Products products = new Products();
                        products.addProduct(productDescription);
                        System.out.println("Product added to the auction successfully.");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } else {
                System.out.println("Invalid input. Please enter a valid option.");
                scanner.next(); // Clear the invalid input from the scanner
            }
        }
    }
}