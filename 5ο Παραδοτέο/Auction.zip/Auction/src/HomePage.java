import java.util.Scanner;
import java.util.List;

public class HomePage {
    public static void main(String[] args) throws Exception {
        System.out.println("'Categories', 'Search', 'AuctionPage'");
        Scanner sc = new Scanner(System.in);
        System.out.println("Choose where you want to go");

        String choice;
        do {
            choice = sc.nextLine();

            if (choice.equals("AuctionPage")) {
                System.out.println("Redirecting to the auction page...");
                Products products = new Products();
                List<Description> productList = products.getProductList();
                AuctionPage.displayPrompt(productList);
            } else if (choice.equals("Categories")) {
                System.out.println("Page is down O_O'");
            } else if (choice.equals("Search")) {
                System.out.println("Page not working X_X");
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        } while (!choice.equals("AuctionPage"));

        sc.close();
    }
}